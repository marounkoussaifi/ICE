/**
 */
package org.eclipse.sirius.sample.ice_editor.iCE_Editor;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Component#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Component#getRole <em>Role</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Component#getStates <em>States</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Component#getService <em>Service</em>}</li>
 * </ul>
 *
 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getComponent()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='nameCondition serviceCondition'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot nameCondition='Component.allInstances()-&gt;forAll(c1, c2 | c1 &lt;&gt; c2 implies c1.Name &lt;&gt; c2.Name)' serviceCondition='self.service -&gt; forAll(s1, s2 | s1 &lt;&gt; s2 implies s1.Name &lt;&gt; s2.Name)'"
 * @generated
 */
public interface Component extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getComponent_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Component#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Role</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role</em>' attribute.
	 * @see #setRole(String)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getComponent_Role()
	 * @model required="true"
	 * @generated
	 */
	String getRole();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Component#getRole <em>Role</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Role</em>' attribute.
	 * @see #getRole()
	 * @generated
	 */
	void setRole(String value);

	/**
	 * Returns the value of the '<em><b>States</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>States</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>States</em>' attribute list.
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getComponent_States()
	 * @model
	 * @generated
	 */
	EList<String> getStates();

	/**
	 * Returns the value of the '<em><b>Service</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service</em>' containment reference list.
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getComponent_Service()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Service> getService();

} // Component
