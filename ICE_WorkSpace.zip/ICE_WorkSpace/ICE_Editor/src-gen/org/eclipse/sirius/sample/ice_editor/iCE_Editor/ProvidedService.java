/**
 */
package org.eclipse.sirius.sample.ice_editor.iCE_Editor;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Provided Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getProvidedService()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='cardCheckReq bindReqCheck'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot cardCheckReq='self.bindRequired -&gt; size()&lt;=Cardinality' bindReqCheck='self.bindRequired -&gt; forAll(s | s.ID = self.ID)'"
 * @generated
 */
public interface ProvidedService extends Service {
} // ProvidedService
