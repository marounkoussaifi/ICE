/**
 */
package org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage;
import org.eclipse.sirius.sample.ice_editor.iCE_Editor.ProvidedService;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Provided Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ProvidedServiceImpl extends ServiceImpl implements ProvidedService {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProvidedServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ICE_EditorPackage.Literals.PROVIDED_SERVICE;
	}

} //ProvidedServiceImpl
