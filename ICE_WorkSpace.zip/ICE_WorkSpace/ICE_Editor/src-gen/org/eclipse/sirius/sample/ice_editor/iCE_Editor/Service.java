/**
 */
package org.eclipse.sirius.sample.ice_editor.iCE_Editor;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getID <em>ID</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getIOAction <em>IO Action</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getLauncher <em>Launcher</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getServiceDescription <em>Service Description</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getRules <em>Rules</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getBindRequired <em>Bind Required</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getBindProvided <em>Bind Provided</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getCardinality <em>Cardinality</em>}</li>
 * </ul>
 *
 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService()
 * @model abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='rulecheck'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot rulecheck='self.Rules -&gt; \n\t\t\tforAll(r | r.matches(\'^Launcher\\\\s(AND\\\\sSTATE(==|&lt;|&gt;|&lt;=|&gt;=)(\\\\w)+\\\\s|AND\\\\sVAL@INPUT((==|&lt;|&gt;|&lt;=|&gt;=)(\\\\w)+)*\\\\s)*--&gt;\\\\s(IOAction|STATE=(\\\\w)+|IOAction\\\\sAND\\\\sSTATE=(\\\\w)+|NOP)$\'))\n'"
 * @generated
 */
public interface Service extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ID</em>' attribute.
	 * @see #setID(String)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_ID()
	 * @model required="true"
	 * @generated
	 */
	String getID();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getID <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ID</em>' attribute.
	 * @see #getID()
	 * @generated
	 */
	void setID(String value);

	/**
	 * Returns the value of the '<em><b>IO Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>IO Action</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>IO Action</em>' attribute.
	 * @see #setIOAction(String)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_IOAction()
	 * @model required="true"
	 * @generated
	 */
	String getIOAction();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getIOAction <em>IO Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>IO Action</em>' attribute.
	 * @see #getIOAction()
	 * @generated
	 */
	void setIOAction(String value);

	/**
	 * Returns the value of the '<em><b>Launcher</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Launcher</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Launcher</em>' attribute.
	 * @see #setLauncher(String)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_Launcher()
	 * @model default="" required="true"
	 * @generated
	 */
	String getLauncher();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getLauncher <em>Launcher</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Launcher</em>' attribute.
	 * @see #getLauncher()
	 * @generated
	 */
	void setLauncher(String value);

	/**
	 * Returns the value of the '<em><b>Service Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service Description</em>' attribute.
	 * @see #setServiceDescription(String)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_ServiceDescription()
	 * @model required="true"
	 * @generated
	 */
	String getServiceDescription();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getServiceDescription <em>Service Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service Description</em>' attribute.
	 * @see #getServiceDescription()
	 * @generated
	 */
	void setServiceDescription(String value);

	/**
	 * Returns the value of the '<em><b>Rules</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rules</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rules</em>' attribute list.
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_Rules()
	 * @model required="true"
	 * @generated
	 */
	EList<String> getRules();

	/**
	 * Returns the value of the '<em><b>Bind Required</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service}.
	 * It is bidirectional and its opposite is '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getBindProvided <em>Bind Provided</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bind Required</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bind Required</em>' reference list.
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_BindRequired()
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getBindProvided
	 * @model opposite="bindProvided"
	 * @generated
	 */
	EList<Service> getBindRequired();

	/**
	 * Returns the value of the '<em><b>Bind Provided</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service}.
	 * It is bidirectional and its opposite is '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getBindRequired <em>Bind Required</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bind Provided</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bind Provided</em>' reference list.
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_BindProvided()
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getBindRequired
	 * @model opposite="bindRequired"
	 * @generated
	 */
	EList<Service> getBindProvided();

	/**
	 * Returns the value of the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cardinality</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cardinality</em>' attribute.
	 * @see #setCardinality(int)
	 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage#getService_Cardinality()
	 * @model required="true"
	 * @generated
	 */
	int getCardinality();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service#getCardinality <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cardinality</em>' attribute.
	 * @see #getCardinality()
	 * @generated
	 */
	void setCardinality(int value);

} // Service
