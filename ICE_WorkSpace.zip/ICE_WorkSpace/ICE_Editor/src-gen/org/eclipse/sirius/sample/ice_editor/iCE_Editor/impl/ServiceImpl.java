/**
 */
package org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage;
import org.eclipse.sirius.sample.ice_editor.iCE_Editor.Service;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getID <em>ID</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getIOAction <em>IO Action</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getLauncher <em>Launcher</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getServiceDescription <em>Service Description</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getRules <em>Rules</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getBindRequired <em>Bind Required</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getBindProvided <em>Bind Provided</em>}</li>
 *   <li>{@link org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl.ServiceImpl#getCardinality <em>Cardinality</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ServiceImpl extends MinimalEObjectImpl.Container implements Service {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getIOAction() <em>IO Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIOAction()
	 * @generated
	 * @ordered
	 */
	protected static final String IO_ACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIOAction() <em>IO Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIOAction()
	 * @generated
	 * @ordered
	 */
	protected String ioAction = IO_ACTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getLauncher() <em>Launcher</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLauncher()
	 * @generated
	 * @ordered
	 */
	protected static final String LAUNCHER_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getLauncher() <em>Launcher</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLauncher()
	 * @generated
	 * @ordered
	 */
	protected String launcher = LAUNCHER_EDEFAULT;

	/**
	 * The default value of the '{@link #getServiceDescription() <em>Service Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServiceDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String SERVICE_DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getServiceDescription() <em>Service Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServiceDescription()
	 * @generated
	 * @ordered
	 */
	protected String serviceDescription = SERVICE_DESCRIPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRules() <em>Rules</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRules()
	 * @generated
	 * @ordered
	 */
	protected EList<String> rules;

	/**
	 * The cached value of the '{@link #getBindRequired() <em>Bind Required</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBindRequired()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> bindRequired;

	/**
	 * The cached value of the '{@link #getBindProvided() <em>Bind Provided</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBindProvided()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> bindProvided;

	/**
	 * The default value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardinality()
	 * @generated
	 * @ordered
	 */
	protected static final int CARDINALITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardinality()
	 * @generated
	 * @ordered
	 */
	protected int cardinality = CARDINALITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ICE_EditorPackage.Literals.SERVICE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ICE_EditorPackage.SERVICE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getID() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setID(String newID) {
		String oldID = id;
		id = newID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ICE_EditorPackage.SERVICE__ID, oldID, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getIOAction() {
		return ioAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIOAction(String newIOAction) {
		String oldIOAction = ioAction;
		ioAction = newIOAction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ICE_EditorPackage.SERVICE__IO_ACTION, oldIOAction,
					ioAction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLauncher() {
		return launcher;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLauncher(String newLauncher) {
		String oldLauncher = launcher;
		launcher = newLauncher;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ICE_EditorPackage.SERVICE__LAUNCHER, oldLauncher,
					launcher));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getServiceDescription() {
		return serviceDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setServiceDescription(String newServiceDescription) {
		String oldServiceDescription = serviceDescription;
		serviceDescription = newServiceDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ICE_EditorPackage.SERVICE__SERVICE_DESCRIPTION,
					oldServiceDescription, serviceDescription));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<String> getRules() {
		if (rules == null) {
			rules = new EDataTypeUniqueEList<String>(String.class, this, ICE_EditorPackage.SERVICE__RULES);
		}
		return rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getBindRequired() {
		if (bindRequired == null) {
			bindRequired = new EObjectWithInverseResolvingEList.ManyInverse<Service>(Service.class, this,
					ICE_EditorPackage.SERVICE__BIND_REQUIRED, ICE_EditorPackage.SERVICE__BIND_PROVIDED);
		}
		return bindRequired;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getBindProvided() {
		if (bindProvided == null) {
			bindProvided = new EObjectWithInverseResolvingEList.ManyInverse<Service>(Service.class, this,
					ICE_EditorPackage.SERVICE__BIND_PROVIDED, ICE_EditorPackage.SERVICE__BIND_REQUIRED);
		}
		return bindProvided;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCardinality() {
		return cardinality;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardinality(int newCardinality) {
		int oldCardinality = cardinality;
		cardinality = newCardinality;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ICE_EditorPackage.SERVICE__CARDINALITY,
					oldCardinality, cardinality));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ICE_EditorPackage.SERVICE__BIND_REQUIRED:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getBindRequired()).basicAdd(otherEnd, msgs);
		case ICE_EditorPackage.SERVICE__BIND_PROVIDED:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getBindProvided()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ICE_EditorPackage.SERVICE__BIND_REQUIRED:
			return ((InternalEList<?>) getBindRequired()).basicRemove(otherEnd, msgs);
		case ICE_EditorPackage.SERVICE__BIND_PROVIDED:
			return ((InternalEList<?>) getBindProvided()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ICE_EditorPackage.SERVICE__NAME:
			return getName();
		case ICE_EditorPackage.SERVICE__ID:
			return getID();
		case ICE_EditorPackage.SERVICE__IO_ACTION:
			return getIOAction();
		case ICE_EditorPackage.SERVICE__LAUNCHER:
			return getLauncher();
		case ICE_EditorPackage.SERVICE__SERVICE_DESCRIPTION:
			return getServiceDescription();
		case ICE_EditorPackage.SERVICE__RULES:
			return getRules();
		case ICE_EditorPackage.SERVICE__BIND_REQUIRED:
			return getBindRequired();
		case ICE_EditorPackage.SERVICE__BIND_PROVIDED:
			return getBindProvided();
		case ICE_EditorPackage.SERVICE__CARDINALITY:
			return getCardinality();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ICE_EditorPackage.SERVICE__NAME:
			setName((String) newValue);
			return;
		case ICE_EditorPackage.SERVICE__ID:
			setID((String) newValue);
			return;
		case ICE_EditorPackage.SERVICE__IO_ACTION:
			setIOAction((String) newValue);
			return;
		case ICE_EditorPackage.SERVICE__LAUNCHER:
			setLauncher((String) newValue);
			return;
		case ICE_EditorPackage.SERVICE__SERVICE_DESCRIPTION:
			setServiceDescription((String) newValue);
			return;
		case ICE_EditorPackage.SERVICE__RULES:
			getRules().clear();
			getRules().addAll((Collection<? extends String>) newValue);
			return;
		case ICE_EditorPackage.SERVICE__BIND_REQUIRED:
			getBindRequired().clear();
			getBindRequired().addAll((Collection<? extends Service>) newValue);
			return;
		case ICE_EditorPackage.SERVICE__BIND_PROVIDED:
			getBindProvided().clear();
			getBindProvided().addAll((Collection<? extends Service>) newValue);
			return;
		case ICE_EditorPackage.SERVICE__CARDINALITY:
			setCardinality((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ICE_EditorPackage.SERVICE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case ICE_EditorPackage.SERVICE__ID:
			setID(ID_EDEFAULT);
			return;
		case ICE_EditorPackage.SERVICE__IO_ACTION:
			setIOAction(IO_ACTION_EDEFAULT);
			return;
		case ICE_EditorPackage.SERVICE__LAUNCHER:
			setLauncher(LAUNCHER_EDEFAULT);
			return;
		case ICE_EditorPackage.SERVICE__SERVICE_DESCRIPTION:
			setServiceDescription(SERVICE_DESCRIPTION_EDEFAULT);
			return;
		case ICE_EditorPackage.SERVICE__RULES:
			getRules().clear();
			return;
		case ICE_EditorPackage.SERVICE__BIND_REQUIRED:
			getBindRequired().clear();
			return;
		case ICE_EditorPackage.SERVICE__BIND_PROVIDED:
			getBindProvided().clear();
			return;
		case ICE_EditorPackage.SERVICE__CARDINALITY:
			setCardinality(CARDINALITY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ICE_EditorPackage.SERVICE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case ICE_EditorPackage.SERVICE__ID:
			return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
		case ICE_EditorPackage.SERVICE__IO_ACTION:
			return IO_ACTION_EDEFAULT == null ? ioAction != null : !IO_ACTION_EDEFAULT.equals(ioAction);
		case ICE_EditorPackage.SERVICE__LAUNCHER:
			return LAUNCHER_EDEFAULT == null ? launcher != null : !LAUNCHER_EDEFAULT.equals(launcher);
		case ICE_EditorPackage.SERVICE__SERVICE_DESCRIPTION:
			return SERVICE_DESCRIPTION_EDEFAULT == null ? serviceDescription != null
					: !SERVICE_DESCRIPTION_EDEFAULT.equals(serviceDescription);
		case ICE_EditorPackage.SERVICE__RULES:
			return rules != null && !rules.isEmpty();
		case ICE_EditorPackage.SERVICE__BIND_REQUIRED:
			return bindRequired != null && !bindRequired.isEmpty();
		case ICE_EditorPackage.SERVICE__BIND_PROVIDED:
			return bindProvided != null && !bindProvided.isEmpty();
		case ICE_EditorPackage.SERVICE__CARDINALITY:
			return cardinality != CARDINALITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", ID: ");
		result.append(id);
		result.append(", IOAction: ");
		result.append(ioAction);
		result.append(", Launcher: ");
		result.append(launcher);
		result.append(", ServiceDescription: ");
		result.append(serviceDescription);
		result.append(", Rules: ");
		result.append(rules);
		result.append(", Cardinality: ");
		result.append(cardinality);
		result.append(')');
		return result.toString();
	}

} //ServiceImpl
