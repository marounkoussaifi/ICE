/**
 */
package org.eclipse.sirius.sample.ice_editor.iCE_Editor.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage;
import org.eclipse.sirius.sample.ice_editor.iCE_Editor.RequiredService;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Required Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RequiredServiceImpl extends ServiceImpl implements RequiredService {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequiredServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ICE_EditorPackage.Literals.REQUIRED_SERVICE;
	}

} //RequiredServiceImpl
