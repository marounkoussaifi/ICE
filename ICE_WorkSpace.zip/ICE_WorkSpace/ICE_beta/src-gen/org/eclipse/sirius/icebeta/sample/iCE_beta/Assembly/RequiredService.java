/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Required Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package#getRequiredService()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='launcherCheckRequired'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot launcherCheckRequired='self.serviceDescription.Launcher = LauncherTypeRequired'"
 * @generated
 */
public interface RequiredService extends Service {
} // RequiredService
