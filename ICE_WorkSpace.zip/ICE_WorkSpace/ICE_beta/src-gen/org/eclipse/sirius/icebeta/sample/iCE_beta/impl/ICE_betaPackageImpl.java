/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.impl;

import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.impl.NewPackage1PackageImpl;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.impl.NewPackage3PackageImpl;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.NewPackage2PackageImpl;

import org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaFactory;
import org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaPackage;
import org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeProvided;
import org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeRequired;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ICE_betaPackageImpl extends EPackageImpl implements ICE_betaPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum launcherTypeRequiredEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum launcherTypeProvidedEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ICE_betaPackageImpl() {
		super(eNS_URI, ICE_betaFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ICE_betaPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ICE_betaPackage init() {
		if (isInited)
			return (ICE_betaPackage) EPackage.Registry.INSTANCE.getEPackage(ICE_betaPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredICE_betaPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ICE_betaPackageImpl theICE_betaPackage = registeredICE_betaPackage instanceof ICE_betaPackageImpl
				? (ICE_betaPackageImpl) registeredICE_betaPackage
				: new ICE_betaPackageImpl();

		isInited = true;

		// Initialize simple dependencies
		NewPackage1Package.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		Object registeredPackage = EPackage.Registry.INSTANCE.getEPackage(NewPackage1Package.eNS_URI);
		NewPackage1PackageImpl theNewPackage1Package = (NewPackage1PackageImpl) (registeredPackage instanceof NewPackage1PackageImpl
				? registeredPackage
				: NewPackage1Package.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(NewPackage2Package.eNS_URI);
		NewPackage2PackageImpl theNewPackage2Package = (NewPackage2PackageImpl) (registeredPackage instanceof NewPackage2PackageImpl
				? registeredPackage
				: NewPackage2Package.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(NewPackage3Package.eNS_URI);
		NewPackage3PackageImpl theNewPackage3Package = (NewPackage3PackageImpl) (registeredPackage instanceof NewPackage3PackageImpl
				? registeredPackage
				: NewPackage3Package.eINSTANCE);

		// Create package meta-data objects
		theICE_betaPackage.createPackageContents();
		theNewPackage1Package.createPackageContents();
		theNewPackage2Package.createPackageContents();
		theNewPackage3Package.createPackageContents();

		// Initialize created meta-data
		theICE_betaPackage.initializePackageContents();
		theNewPackage1Package.initializePackageContents();
		theNewPackage2Package.initializePackageContents();
		theNewPackage3Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theICE_betaPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ICE_betaPackage.eNS_URI, theICE_betaPackage);
		return theICE_betaPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getLauncherTypeRequired() {
		return launcherTypeRequiredEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getLauncherTypeProvided() {
		return launcherTypeProvidedEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ICE_betaFactory getICE_betaFactory() {
		return (ICE_betaFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create enums
		launcherTypeProvidedEEnum = createEEnum(LAUNCHER_TYPE_PROVIDED);
		launcherTypeRequiredEEnum = createEEnum(LAUNCHER_TYPE_REQUIRED);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		NewPackage1Package theNewPackage1Package = (NewPackage1Package) EPackage.Registry.INSTANCE
				.getEPackage(NewPackage1Package.eNS_URI);
		NewPackage2Package theNewPackage2Package = (NewPackage2Package) EPackage.Registry.INSTANCE
				.getEPackage(NewPackage2Package.eNS_URI);
		NewPackage3Package theNewPackage3Package = (NewPackage3Package) EPackage.Registry.INSTANCE
				.getEPackage(NewPackage3Package.eNS_URI);

		// Add subpackages
		getESubpackages().add(theNewPackage1Package);
		getESubpackages().add(theNewPackage2Package);
		getESubpackages().add(theNewPackage3Package);

		// Initialize enums and add enum literals
		initEEnum(launcherTypeProvidedEEnum, LauncherTypeProvided.class, "LauncherTypeProvided");
		addEEnumLiteral(launcherTypeProvidedEEnum, LauncherTypeProvided.ON_REQUIRED);

		initEEnum(launcherTypeRequiredEEnum, LauncherTypeRequired.class, "LauncherTypeRequired");
		addEEnumLiteral(launcherTypeRequiredEEnum, LauncherTypeRequired.ON_BUTTON_PRESSED);
		addEEnumLiteral(launcherTypeRequiredEEnum, LauncherTypeRequired.ON_SLIDER_DRAGGED);
		addEEnumLiteral(launcherTypeRequiredEEnum, LauncherTypeRequired.ON_TRIGGERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/OCL/Import
		createImportAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Import</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createImportAnnotations() {
		String source = "http://www.eclipse.org/OCL/Import";
		addAnnotation(this, source, new String[] { "ecore.xml.type", "http://www.eclipse.org/emf/2003/XMLType" });
	}

} //ICE_betaPackageImpl
