/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ServiceImpl#getBindRequired <em>Bind Required</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ServiceImpl#getBindProvided <em>Bind Provided</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ServiceImpl#getServiceDescription <em>Service Description</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ServiceImpl extends MinimalEObjectImpl.Container implements Service {
	/**
	 * The cached value of the '{@link #getBindRequired() <em>Bind Required</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBindRequired()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> bindRequired;

	/**
	 * The cached value of the '{@link #getBindProvided() <em>Bind Provided</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBindProvided()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> bindProvided;

	/**
	 * The cached value of the '{@link #getServiceDescription() <em>Service Description</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServiceDescription()
	 * @generated
	 * @ordered
	 */
	protected ServiceDescription serviceDescription;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewPackage1Package.Literals.SERVICE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getBindRequired() {
		if (bindRequired == null) {
			bindRequired = new EObjectWithInverseResolvingEList.ManyInverse<Service>(Service.class, this,
					NewPackage1Package.SERVICE__BIND_REQUIRED, NewPackage1Package.SERVICE__BIND_PROVIDED);
		}
		return bindRequired;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getBindProvided() {
		if (bindProvided == null) {
			bindProvided = new EObjectWithInverseResolvingEList.ManyInverse<Service>(Service.class, this,
					NewPackage1Package.SERVICE__BIND_PROVIDED, NewPackage1Package.SERVICE__BIND_REQUIRED);
		}
		return bindProvided;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServiceDescription getServiceDescription() {
		return serviceDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetServiceDescription(ServiceDescription newServiceDescription,
			NotificationChain msgs) {
		ServiceDescription oldServiceDescription = serviceDescription;
		serviceDescription = newServiceDescription;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					NewPackage1Package.SERVICE__SERVICE_DESCRIPTION, oldServiceDescription, newServiceDescription);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setServiceDescription(ServiceDescription newServiceDescription) {
		if (newServiceDescription != serviceDescription) {
			NotificationChain msgs = null;
			if (serviceDescription != null)
				msgs = ((InternalEObject) serviceDescription).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - NewPackage1Package.SERVICE__SERVICE_DESCRIPTION, null, msgs);
			if (newServiceDescription != null)
				msgs = ((InternalEObject) newServiceDescription).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - NewPackage1Package.SERVICE__SERVICE_DESCRIPTION, null, msgs);
			msgs = basicSetServiceDescription(newServiceDescription, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NewPackage1Package.SERVICE__SERVICE_DESCRIPTION,
					newServiceDescription, newServiceDescription));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__BIND_REQUIRED:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getBindRequired()).basicAdd(otherEnd, msgs);
		case NewPackage1Package.SERVICE__BIND_PROVIDED:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getBindProvided()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__BIND_REQUIRED:
			return ((InternalEList<?>) getBindRequired()).basicRemove(otherEnd, msgs);
		case NewPackage1Package.SERVICE__BIND_PROVIDED:
			return ((InternalEList<?>) getBindProvided()).basicRemove(otherEnd, msgs);
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			return basicSetServiceDescription(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__BIND_REQUIRED:
			return getBindRequired();
		case NewPackage1Package.SERVICE__BIND_PROVIDED:
			return getBindProvided();
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			return getServiceDescription();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__BIND_REQUIRED:
			getBindRequired().clear();
			getBindRequired().addAll((Collection<? extends Service>) newValue);
			return;
		case NewPackage1Package.SERVICE__BIND_PROVIDED:
			getBindProvided().clear();
			getBindProvided().addAll((Collection<? extends Service>) newValue);
			return;
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			setServiceDescription((ServiceDescription) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__BIND_REQUIRED:
			getBindRequired().clear();
			return;
		case NewPackage1Package.SERVICE__BIND_PROVIDED:
			getBindProvided().clear();
			return;
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			setServiceDescription((ServiceDescription) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__BIND_REQUIRED:
			return bindRequired != null && !bindRequired.isEmpty();
		case NewPackage1Package.SERVICE__BIND_PROVIDED:
			return bindProvided != null && !bindProvided.isEmpty();
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			return serviceDescription != null;
		}
		return super.eIsSet(featureID);
	}

} //ServiceImpl
