/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Provided Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package#getProvidedService()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='launcherCheckProvided cardCheckRequired matchingId'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot launcherCheckProvided='self.ServiceDescription.Launcher = LauncherTypeProvided' cardCheckRequired='self.bindRequired -&gt; size() &lt; self.ServiceDescription.Cardinality ' matchingId='self.bindRequired -&gt; forAll(s | s.ServiceDescription.MatchingID = self.ServiceDescription.MatchingID)'"
 * @generated
 */
public interface ProvidedService extends Service {
} // ProvidedService
