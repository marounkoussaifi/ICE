/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Combination Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.CombinationRule#getState <em>State</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.CombinationRule#getRules <em>Rules</em>}</li>
 * </ul>
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Package#getCombinationRule()
 * @model
 * @generated
 */
public interface CombinationRule extends EObject {
	/**
	 * Returns the value of the '<em><b>State</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' attribute list.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Package#getCombinationRule_State()
	 * @model default="" derived="true"
	 * @generated
	 */
	EList<String> getState();

	/**
	 * Returns the value of the '<em><b>Rules</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.Rule}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rules</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rules</em>' reference list.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Package#getCombinationRule_Rules()
	 * @model required="true"
	 * @generated
	 */
	EList<Rule> getRules();

} // CombinationRule
