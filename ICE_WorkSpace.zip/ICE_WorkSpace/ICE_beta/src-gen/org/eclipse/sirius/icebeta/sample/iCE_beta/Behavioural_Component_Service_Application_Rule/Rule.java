/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.Rule#getEvent <em>Event</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.Rule#getCondition <em>Condition</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.Rule#getAction <em>Action</em>}</li>
 * </ul>
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.NewPackage3Package#getRule()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='conditionCheck consequenceCheck'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot conditionCheck='self.Condition.matches(\'^Launcher\\\\s(AND\\\\sSTATE(==|&lt;|&gt;|&lt;=|&gt;=)(\\\\w)+\\\\s|AND\\\\sVAL@INPUT((==|&lt;|&gt;|&lt;=|&gt;=)(\\\\w)+)*\\\\s)*\')' consequenceCheck='self.Action.matches(\'\\\\s(IOAction|STATE=(\\\\w)+|IOAction\\\\sAND\\\\sSTATE=(\\\\w)+|NOP)$\')'"
 * @generated
 */
public interface Rule extends EObject {
	/**
	 * Returns the value of the '<em><b>Event</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' attribute.
	 * @see #setEvent(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.NewPackage3Package#getRule_Event()
	 * @model required="true"
	 * @generated
	 */
	String getEvent();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.Rule#getEvent <em>Event</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event</em>' attribute.
	 * @see #getEvent()
	 * @generated
	 */
	void setEvent(String value);

	/**
	 * Returns the value of the '<em><b>Condition</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Condition</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Condition</em>' attribute.
	 * @see #setCondition(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.NewPackage3Package#getRule_Condition()
	 * @model required="true"
	 * @generated
	 */
	String getCondition();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.Rule#getCondition <em>Condition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Condition</em>' attribute.
	 * @see #getCondition()
	 * @generated
	 */
	void setCondition(String value);

	/**
	 * Returns the value of the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Action</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action</em>' attribute.
	 * @see #setAction(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.NewPackage3Package#getRule_Action()
	 * @model required="true"
	 * @generated
	 */
	String getAction();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioural_Component_Service_Application_Rule.Rule#getAction <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Action</em>' attribute.
	 * @see #getAction()
	 * @generated
	 */
	void setAction(String value);

} // Rule
