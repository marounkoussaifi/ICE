/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaPackage
 * @generated
 */
public interface ICE_betaFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ICE_betaFactory eINSTANCE = org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaFactoryImpl.init();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ICE_betaPackage getICE_betaPackage();

} //ICE_betaFactory
