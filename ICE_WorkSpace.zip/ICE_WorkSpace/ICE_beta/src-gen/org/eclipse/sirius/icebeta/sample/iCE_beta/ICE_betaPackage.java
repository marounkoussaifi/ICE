/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta;

import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import ecore.xml.type='http://www.eclipse.org/emf/2003/XMLType'"
 * @generated
 */
public interface ICE_betaPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "iCE_beta";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/sirius/sample/iCE_beta";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "iCE_beta";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ICE_betaPackage eINSTANCE = org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeRequired <em>Launcher Type Required</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeRequired
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaPackageImpl#getLauncherTypeRequired()
	 * @generated
	 */
	int LAUNCHER_TYPE_REQUIRED = 1;

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeProvided <em>Launcher Type Provided</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeProvided
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaPackageImpl#getLauncherTypeProvided()
	 * @generated
	 */
	int LAUNCHER_TYPE_PROVIDED = 0;

	/**
	 * Returns the meta object for enum '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeRequired <em>Launcher Type Required</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Launcher Type Required</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeRequired
	 * @generated
	 */
	EEnum getLauncherTypeRequired();

	/**
	 * Returns the meta object for enum '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeProvided <em>Launcher Type Provided</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Launcher Type Provided</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeProvided
	 * @generated
	 */
	EEnum getLauncherTypeProvided();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ICE_betaFactory getICE_betaFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeRequired <em>Launcher Type Required</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeRequired
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaPackageImpl#getLauncherTypeRequired()
		 * @generated
		 */
		EEnum LAUNCHER_TYPE_REQUIRED = eINSTANCE.getLauncherTypeRequired();

		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeProvided <em>Launcher Type Provided</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.LauncherTypeProvided
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaPackageImpl#getLauncherTypeProvided()
		 * @generated
		 */
		EEnum LAUNCHER_TYPE_PROVIDED = eINSTANCE.getLauncherTypeProvided();

	}

} //ICE_betaPackage
