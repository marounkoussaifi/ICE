/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Required Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package#getRequiredService()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='launcherCheckRequired cardCheckProv matchingId'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot launcherCheckRequired='self.ServiceDescription.Launcher = LauncherTypeRequired' cardCheckProv='self.bindProvided -&gt; size() &lt; self.ServiceDescription.Cardinality ' matchingId='self.bindProvided -&gt; forAll(s | s.ServiceDescription.MatchingID = self.ServiceDescription.MatchingID)'"
 * @generated
 */
public interface RequiredService extends Service {
} // RequiredService
