/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.CombinationRule;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service Description</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getLauncher <em>Launcher</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getIOAction <em>IO Action</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getTextualDescription <em>Textual Description</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getRule <em>Rule</em>}</li>
 * </ul>
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package#getServiceDescription()
 * @model
 * @generated
 */
public interface ServiceDescription extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package#getServiceDescription_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Launcher</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Launcher</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Launcher</em>' attribute.
	 * @see #setLauncher(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package#getServiceDescription_Launcher()
	 * @model required="true"
	 * @generated
	 */
	String getLauncher();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getLauncher <em>Launcher</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Launcher</em>' attribute.
	 * @see #getLauncher()
	 * @generated
	 */
	void setLauncher(String value);

	/**
	 * Returns the value of the '<em><b>IO Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>IO Action</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>IO Action</em>' attribute.
	 * @see #setIOAction(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package#getServiceDescription_IOAction()
	 * @model required="true"
	 * @generated
	 */
	String getIOAction();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getIOAction <em>IO Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>IO Action</em>' attribute.
	 * @see #getIOAction()
	 * @generated
	 */
	void setIOAction(String value);

	/**
	 * Returns the value of the '<em><b>Textual Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Textual Description</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Textual Description</em>' attribute.
	 * @see #setTextualDescription(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package#getServiceDescription_TextualDescription()
	 * @model required="true"
	 * @generated
	 */
	String getTextualDescription();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getTextualDescription <em>Textual Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Textual Description</em>' attribute.
	 * @see #getTextualDescription()
	 * @generated
	 */
	void setTextualDescription(String value);

	/**
	 * Returns the value of the '<em><b>Rule</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rule</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rule</em>' containment reference.
	 * @see #setRule(CombinationRule)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package#getServiceDescription_Rule()
	 * @model containment="true" required="true"
	 * @generated
	 */
	CombinationRule getRule();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getRule <em>Rule</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rule</em>' containment reference.
	 * @see #getRule()
	 * @generated
	 */
	void setRule(CombinationRule value);

} // ServiceDescription
