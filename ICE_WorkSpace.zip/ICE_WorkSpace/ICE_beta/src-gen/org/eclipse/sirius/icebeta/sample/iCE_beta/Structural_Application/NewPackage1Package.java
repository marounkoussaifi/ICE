/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Factory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface NewPackage1Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Structural_Application";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/sirius/sample/iCE_beta_env";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "env_ice";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NewPackage1Package eINSTANCE = org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl
			.init();

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.EnvironmentImpl <em>Environment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.EnvironmentImpl
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getEnvironment()
	 * @generated
	 */
	int ENVIRONMENT = 0;

	/**
	 * The feature id for the '<em><b>Components</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT__COMPONENTS = 0;

	/**
	 * The number of structural features of the '<em>Environment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Environment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ServiceImpl <em>Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ServiceImpl
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getService()
	 * @generated
	 */
	int SERVICE = 2;

	/**
	 * The feature id for the '<em><b>Bind Required</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__BIND_REQUIRED = 0;

	/**
	 * The feature id for the '<em><b>Bind Provided</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__BIND_PROVIDED = 1;

	/**
	 * The feature id for the '<em><b>Service Description</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__SERVICE_DESCRIPTION = 2;

	/**
	 * The number of structural features of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.RequiredServiceImpl <em>Required Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.RequiredServiceImpl
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getRequiredService()
	 * @generated
	 */
	int REQUIRED_SERVICE = 1;

	/**
	 * The feature id for the '<em><b>Bind Required</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_SERVICE__BIND_REQUIRED = SERVICE__BIND_REQUIRED;

	/**
	 * The feature id for the '<em><b>Bind Provided</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_SERVICE__BIND_PROVIDED = SERVICE__BIND_PROVIDED;

	/**
	 * The feature id for the '<em><b>Service Description</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_SERVICE__SERVICE_DESCRIPTION = SERVICE__SERVICE_DESCRIPTION;

	/**
	 * The number of structural features of the '<em>Required Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_SERVICE_FEATURE_COUNT = SERVICE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Required Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REQUIRED_SERVICE_OPERATION_COUNT = SERVICE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ComponentImpl <em>Component</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ComponentImpl
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getComponent()
	 * @generated
	 */
	int COMPONENT = 3;

	/**
	 * The feature id for the '<em><b>Services</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT__SERVICES = 0;

	/**
	 * The feature id for the '<em><b>Component Description</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT__COMPONENT_DESCRIPTION = 1;

	/**
	 * The number of structural features of the '<em>Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ProvidedServiceImpl <em>Provided Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ProvidedServiceImpl
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getProvidedService()
	 * @generated
	 */
	int PROVIDED_SERVICE = 4;

	/**
	 * The feature id for the '<em><b>Bind Required</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_SERVICE__BIND_REQUIRED = SERVICE__BIND_REQUIRED;

	/**
	 * The feature id for the '<em><b>Bind Provided</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_SERVICE__BIND_PROVIDED = SERVICE__BIND_PROVIDED;

	/**
	 * The feature id for the '<em><b>Service Description</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_SERVICE__SERVICE_DESCRIPTION = SERVICE__SERVICE_DESCRIPTION;

	/**
	 * The number of structural features of the '<em>Provided Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_SERVICE_FEATURE_COUNT = SERVICE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Provided Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVIDED_SERVICE_OPERATION_COUNT = SERVICE_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Environment <em>Environment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Environment</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Environment
	 * @generated
	 */
	EClass getEnvironment();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Environment#getComponents <em>Components</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Components</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Environment#getComponents()
	 * @see #getEnvironment()
	 * @generated
	 */
	EReference getEnvironment_Components();

	/**
	 * Returns the meta object for class '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.RequiredService <em>Required Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Required Service</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.RequiredService
	 * @generated
	 */
	EClass getRequiredService();

	/**
	 * Returns the meta object for class '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service
	 * @generated
	 */
	EClass getService();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindRequired <em>Bind Required</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Bind Required</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindRequired()
	 * @see #getService()
	 * @generated
	 */
	EReference getService_BindRequired();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindProvided <em>Bind Provided</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Bind Provided</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindProvided()
	 * @see #getService()
	 * @generated
	 */
	EReference getService_BindProvided();

	/**
	 * Returns the meta object for the containment reference '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getServiceDescription <em>Service Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Service Description</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getServiceDescription()
	 * @see #getService()
	 * @generated
	 */
	EReference getService_ServiceDescription();

	/**
	 * Returns the meta object for class '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Component <em>Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Component</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Component
	 * @generated
	 */
	EClass getComponent();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Component#getServices <em>Services</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Services</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Component#getServices()
	 * @see #getComponent()
	 * @generated
	 */
	EReference getComponent_Services();

	/**
	 * Returns the meta object for the containment reference '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Component#getComponentDescription <em>Component Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Component Description</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Component#getComponentDescription()
	 * @see #getComponent()
	 * @generated
	 */
	EReference getComponent_ComponentDescription();

	/**
	 * Returns the meta object for class '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.ProvidedService <em>Provided Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Provided Service</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.ProvidedService
	 * @generated
	 */
	EClass getProvidedService();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	NewPackage1Factory getNewPackage1Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.EnvironmentImpl <em>Environment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.EnvironmentImpl
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getEnvironment()
		 * @generated
		 */
		EClass ENVIRONMENT = eINSTANCE.getEnvironment();

		/**
		 * The meta object literal for the '<em><b>Components</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENVIRONMENT__COMPONENTS = eINSTANCE.getEnvironment_Components();

		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.RequiredServiceImpl <em>Required Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.RequiredServiceImpl
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getRequiredService()
		 * @generated
		 */
		EClass REQUIRED_SERVICE = eINSTANCE.getRequiredService();

		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ServiceImpl <em>Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ServiceImpl
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getService()
		 * @generated
		 */
		EClass SERVICE = eINSTANCE.getService();

		/**
		 * The meta object literal for the '<em><b>Bind Required</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVICE__BIND_REQUIRED = eINSTANCE.getService_BindRequired();

		/**
		 * The meta object literal for the '<em><b>Bind Provided</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVICE__BIND_PROVIDED = eINSTANCE.getService_BindProvided();

		/**
		 * The meta object literal for the '<em><b>Service Description</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVICE__SERVICE_DESCRIPTION = eINSTANCE.getService_ServiceDescription();

		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ComponentImpl <em>Component</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ComponentImpl
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getComponent()
		 * @generated
		 */
		EClass COMPONENT = eINSTANCE.getComponent();

		/**
		 * The meta object literal for the '<em><b>Services</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPONENT__SERVICES = eINSTANCE.getComponent_Services();

		/**
		 * The meta object literal for the '<em><b>Component Description</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPONENT__COMPONENT_DESCRIPTION = eINSTANCE.getComponent_ComponentDescription();

		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ProvidedServiceImpl <em>Provided Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ProvidedServiceImpl
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.NewPackage1PackageImpl#getProvidedService()
		 * @generated
		 */
		EClass PROVIDED_SERVICE = eINSTANCE.getProvidedService();

	}

} //NewPackage1Package
