/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Launcher Type Required</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaPackage#getLauncherTypeRequired()
 * @model
 * @generated
 */
public enum LauncherTypeRequired implements Enumerator {
	/**
	 * The '<em><b>On Button Pressed</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ON_BUTTON_PRESSED_VALUE
	 * @generated
	 * @ordered
	 */
	ON_BUTTON_PRESSED(0, "onButtonPressed", "onButtonPressed"),

	/**
	 * The '<em><b>On Slider Dragged</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ON_SLIDER_DRAGGED_VALUE
	 * @generated
	 * @ordered
	 */
	ON_SLIDER_DRAGGED(1, "onSliderDragged", "onSliderDragged"),

	/**
	 * The '<em><b>On Triggered</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ON_TRIGGERED_VALUE
	 * @generated
	 * @ordered
	 */
	ON_TRIGGERED(2, "onTriggered", "onTriggered");

	/**
	 * The '<em><b>On Button Pressed</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>On Button Pressed</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ON_BUTTON_PRESSED
	 * @model name="onButtonPressed"
	 * @generated
	 * @ordered
	 */
	public static final int ON_BUTTON_PRESSED_VALUE = 0;

	/**
	 * The '<em><b>On Slider Dragged</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>On Slider Dragged</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ON_SLIDER_DRAGGED
	 * @model name="onSliderDragged"
	 * @generated
	 * @ordered
	 */
	public static final int ON_SLIDER_DRAGGED_VALUE = 1;

	/**
	 * The '<em><b>On Triggered</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>On Triggered</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ON_TRIGGERED
	 * @model name="onTriggered"
	 * @generated
	 * @ordered
	 */
	public static final int ON_TRIGGERED_VALUE = 2;

	/**
	 * An array of all the '<em><b>Launcher Type Required</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final LauncherTypeRequired[] VALUES_ARRAY = new LauncherTypeRequired[] { ON_BUTTON_PRESSED,
			ON_SLIDER_DRAGGED, ON_TRIGGERED, };

	/**
	 * A public read-only list of all the '<em><b>Launcher Type Required</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<LauncherTypeRequired> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Launcher Type Required</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static LauncherTypeRequired get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			LauncherTypeRequired result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Launcher Type Required</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static LauncherTypeRequired getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			LauncherTypeRequired result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Launcher Type Required</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static LauncherTypeRequired get(int value) {
		switch (value) {
		case ON_BUTTON_PRESSED_VALUE:
			return ON_BUTTON_PRESSED;
		case ON_SLIDER_DRAGGED_VALUE:
			return ON_SLIDER_DRAGGED;
		case ON_TRIGGERED_VALUE:
			return ON_TRIGGERED;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private LauncherTypeRequired(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //LauncherTypeRequired
