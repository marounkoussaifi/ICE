/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Provided Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package#getProvidedService()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='launcherCheckProvided'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot launcherCheckProvided='self.serviceDescription.Launcher = LauncherTypeProvided'"
 * @generated
 */
public interface ProvidedService extends Service {
} // ProvidedService
