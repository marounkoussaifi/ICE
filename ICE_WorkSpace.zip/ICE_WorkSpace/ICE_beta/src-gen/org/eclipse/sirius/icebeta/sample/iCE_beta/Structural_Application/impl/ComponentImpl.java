/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Component;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Component</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ComponentImpl#getServices <em>Services</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl.ComponentImpl#getComponentDescription <em>Component Description</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ComponentImpl extends MinimalEObjectImpl.Container implements Component {
	/**
	 * The cached value of the '{@link #getServices() <em>Services</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServices()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> services;

	/**
	 * The cached value of the '{@link #getComponentDescription() <em>Component Description</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComponentDescription()
	 * @generated
	 * @ordered
	 */
	protected ComponentDescription componentDescription;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComponentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewPackage1Package.Literals.COMPONENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getServices() {
		if (services == null) {
			services = new EObjectContainmentEList<Service>(Service.class, this,
					NewPackage1Package.COMPONENT__SERVICES);
		}
		return services;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ComponentDescription getComponentDescription() {
		return componentDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetComponentDescription(ComponentDescription newComponentDescription,
			NotificationChain msgs) {
		ComponentDescription oldComponentDescription = componentDescription;
		componentDescription = newComponentDescription;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION, oldComponentDescription,
					newComponentDescription);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setComponentDescription(ComponentDescription newComponentDescription) {
		if (newComponentDescription != componentDescription) {
			NotificationChain msgs = null;
			if (componentDescription != null)
				msgs = ((InternalEObject) componentDescription).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION, null, msgs);
			if (newComponentDescription != null)
				msgs = ((InternalEObject) newComponentDescription).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION, null, msgs);
			msgs = basicSetComponentDescription(newComponentDescription, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION,
					newComponentDescription, newComponentDescription));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case NewPackage1Package.COMPONENT__SERVICES:
			return ((InternalEList<?>) getServices()).basicRemove(otherEnd, msgs);
		case NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION:
			return basicSetComponentDescription(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewPackage1Package.COMPONENT__SERVICES:
			return getServices();
		case NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION:
			return getComponentDescription();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewPackage1Package.COMPONENT__SERVICES:
			getServices().clear();
			getServices().addAll((Collection<? extends Service>) newValue);
			return;
		case NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION:
			setComponentDescription((ComponentDescription) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewPackage1Package.COMPONENT__SERVICES:
			getServices().clear();
			return;
		case NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION:
			setComponentDescription((ComponentDescription) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewPackage1Package.COMPONENT__SERVICES:
			return services != null && !services.isEmpty();
		case NewPackage1Package.COMPONENT__COMPONENT_DESCRIPTION:
			return componentDescription != null;
		}
		return super.eIsSet(featureID);
	}

} //ComponentImpl
