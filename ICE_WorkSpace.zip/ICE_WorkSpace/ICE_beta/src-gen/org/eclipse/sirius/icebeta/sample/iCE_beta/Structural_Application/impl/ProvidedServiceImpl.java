/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.ProvidedService;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Provided Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ProvidedServiceImpl extends ServiceImpl implements ProvidedService {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProvidedServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewPackage1Package.Literals.PROVIDED_SERVICE;
	}

} //ProvidedServiceImpl
