/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindRequired <em>Bind Required</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindProvided <em>Bind Provided</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getServiceDescription <em>Service Description</em>}</li>
 * </ul>
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package#getService()
 * @model abstract="true"
 * @generated
 */
public interface Service extends EObject {
	/**
	 * Returns the value of the '<em><b>Bind Required</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service}.
	 * It is bidirectional and its opposite is '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindProvided <em>Bind Provided</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bind Required</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bind Required</em>' reference list.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package#getService_BindRequired()
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindProvided
	 * @model opposite="bindProvided"
	 * @generated
	 */
	EList<Service> getBindRequired();

	/**
	 * Returns the value of the '<em><b>Bind Provided</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service}.
	 * It is bidirectional and its opposite is '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindRequired <em>Bind Required</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bind Provided</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bind Provided</em>' reference list.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package#getService_BindProvided()
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getBindRequired
	 * @model opposite="bindRequired"
	 * @generated
	 */
	EList<Service> getBindProvided();

	/**
	 * Returns the value of the '<em><b>Service Description</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service Description</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service Description</em>' containment reference.
	 * @see #setServiceDescription(ServiceDescription)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package#getService_ServiceDescription()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ServiceDescription getServiceDescription();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.Service#getServiceDescription <em>Service Description</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service Description</em>' containment reference.
	 * @see #getServiceDescription()
	 * @generated
	 */
	void setServiceDescription(ServiceDescription value);

} // Service
