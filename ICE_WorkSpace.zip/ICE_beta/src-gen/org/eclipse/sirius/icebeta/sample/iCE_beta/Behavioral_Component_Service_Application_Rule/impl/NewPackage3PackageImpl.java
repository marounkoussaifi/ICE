/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.impl.NewPackage1PackageImpl;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.CombinationRule;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Factory;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.Rule;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.util.NewPackage3Validator;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.NewPackage2PackageImpl;

import org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaPackage;

import org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NewPackage3PackageImpl extends EPackageImpl implements NewPackage3Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass combinationRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ruleEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private NewPackage3PackageImpl() {
		super(eNS_URI, NewPackage3Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link NewPackage3Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static NewPackage3Package init() {
		if (isInited)
			return (NewPackage3Package) EPackage.Registry.INSTANCE.getEPackage(NewPackage3Package.eNS_URI);

		// Obtain or create and register package
		Object registeredNewPackage3Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		NewPackage3PackageImpl theNewPackage3Package = registeredNewPackage3Package instanceof NewPackage3PackageImpl
				? (NewPackage3PackageImpl) registeredNewPackage3Package
				: new NewPackage3PackageImpl();

		isInited = true;

		// Initialize simple dependencies
		NewPackage1Package.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		Object registeredPackage = EPackage.Registry.INSTANCE.getEPackage(ICE_betaPackage.eNS_URI);
		ICE_betaPackageImpl theICE_betaPackage = (ICE_betaPackageImpl) (registeredPackage instanceof ICE_betaPackageImpl
				? registeredPackage
				: ICE_betaPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(NewPackage1Package.eNS_URI);
		NewPackage1PackageImpl theNewPackage1Package = (NewPackage1PackageImpl) (registeredPackage instanceof NewPackage1PackageImpl
				? registeredPackage
				: NewPackage1Package.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(NewPackage2Package.eNS_URI);
		NewPackage2PackageImpl theNewPackage2Package = (NewPackage2PackageImpl) (registeredPackage instanceof NewPackage2PackageImpl
				? registeredPackage
				: NewPackage2Package.eINSTANCE);

		// Create package meta-data objects
		theNewPackage3Package.createPackageContents();
		theICE_betaPackage.createPackageContents();
		theNewPackage1Package.createPackageContents();
		theNewPackage2Package.createPackageContents();

		// Initialize created meta-data
		theNewPackage3Package.initializePackageContents();
		theICE_betaPackage.initializePackageContents();
		theNewPackage1Package.initializePackageContents();
		theNewPackage2Package.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put(theNewPackage3Package, new EValidator.Descriptor() {
			public EValidator getEValidator() {
				return NewPackage3Validator.INSTANCE;
			}
		});

		// Mark meta-data to indicate it can't be changed
		theNewPackage3Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(NewPackage3Package.eNS_URI, theNewPackage3Package);
		return theNewPackage3Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCombinationRule() {
		return combinationRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCombinationRule_State() {
		return (EAttribute) combinationRuleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCombinationRule_Rules() {
		return (EReference) combinationRuleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRule() {
		return ruleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRule_Event() {
		return (EAttribute) ruleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRule_Condition() {
		return (EAttribute) ruleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRule_Action() {
		return (EAttribute) ruleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewPackage3Factory getNewPackage3Factory() {
		return (NewPackage3Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		combinationRuleEClass = createEClass(COMBINATION_RULE);
		createEAttribute(combinationRuleEClass, COMBINATION_RULE__STATE);
		createEReference(combinationRuleEClass, COMBINATION_RULE__RULES);

		ruleEClass = createEClass(RULE);
		createEAttribute(ruleEClass, RULE__EVENT);
		createEAttribute(ruleEClass, RULE__CONDITION);
		createEAttribute(ruleEClass, RULE__ACTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(combinationRuleEClass, CombinationRule.class, "CombinationRule", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCombinationRule_State(), ecorePackage.getEString(), "State", "", 0, -1, CombinationRule.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getCombinationRule_Rules(), this.getRule(), null, "rules", null, 1, -1, CombinationRule.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ruleEClass, Rule.class, "Rule", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRule_Event(), ecorePackage.getEString(), "Event", null, 1, 1, Rule.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRule_Condition(), ecorePackage.getEString(), "Condition", null, 1, 1, Rule.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRule_Action(), ecorePackage.getEString(), "Action", null, 1, 1, Rule.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";
		addAnnotation(this, source,
				new String[] { "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
						"settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "validationDelegates",
						"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot" });
		addAnnotation(ruleEClass, source, new String[] { "constraints", "conditionCheck consequenceCheck" });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";
		addAnnotation(ruleEClass, source, new String[] { "conditionCheck",
				"self.Condition.matches(\'^Launcher\\\\s(AND\\\\sSTATE(==|<|>|<=|>=)(\\\\w)+\\\\s|AND\\\\sVAL@INPUT((==|<|>|<=|>=)(\\\\w)+)*\\\\s)*\')",
				"consequenceCheck",
				"self.Action.matches(\'\\\\s(IOAction|STATE=(\\\\w)+|IOAction\\\\sAND\\\\sSTATE=(\\\\w)+|NOP)$\')" });
	}

} //NewPackage3PackageImpl
