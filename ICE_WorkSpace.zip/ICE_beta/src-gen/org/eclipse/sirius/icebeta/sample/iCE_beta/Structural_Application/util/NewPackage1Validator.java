/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.util;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package
 * @generated
 */
public class NewPackage1Validator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final NewPackage1Validator INSTANCE = new NewPackage1Validator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewPackage1Validator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
		return NewPackage1Package.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		switch (classifierID) {
		case NewPackage1Package.ENVIRONMENT:
			return validateEnvironment((Environment) value, diagnostics, context);
		case NewPackage1Package.REQUIRED_SERVICE:
			return validateRequiredService((RequiredService) value, diagnostics, context);
		case NewPackage1Package.SERVICE:
			return validateService((Service) value, diagnostics, context);
		case NewPackage1Package.COMPONENT:
			return validateComponent((Component) value, diagnostics, context);
		case NewPackage1Package.PROVIDED_SERVICE:
			return validateProvidedService((ProvidedService) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnvironment(Environment environment, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(environment, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequiredService(RequiredService requiredService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		if (!validate_NoCircularContainment(requiredService, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateRequiredService_launcherCheckRequired(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateRequiredService_cardCheckProv(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateRequiredService_matchingId(requiredService, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the launcherCheckRequired constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String REQUIRED_SERVICE__LAUNCHER_CHECK_REQUIRED__EEXPRESSION = "self.ServiceDescription.Launcher = LauncherTypeRequired";

	/**
	 * Validates the launcherCheckRequired constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequiredService_launcherCheckRequired(RequiredService requiredService,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate(NewPackage1Package.Literals.REQUIRED_SERVICE, requiredService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "launcherCheckRequired",
				REQUIRED_SERVICE__LAUNCHER_CHECK_REQUIRED__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the cardCheckProv constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String REQUIRED_SERVICE__CARD_CHECK_PROV__EEXPRESSION = "self.bindProvided -> size() < self.ServiceDescription.Cardinality ";

	/**
	 * Validates the cardCheckProv constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequiredService_cardCheckProv(RequiredService requiredService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(NewPackage1Package.Literals.REQUIRED_SERVICE, requiredService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "cardCheckProv",
				REQUIRED_SERVICE__CARD_CHECK_PROV__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the matchingId constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String REQUIRED_SERVICE__MATCHING_ID__EEXPRESSION = "self.bindProvided -> forAll(s | s.ServiceDescription.MatchingID = self.ServiceDescription.MatchingID)";

	/**
	 * Validates the matchingId constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequiredService_matchingId(RequiredService requiredService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(NewPackage1Package.Literals.REQUIRED_SERVICE, requiredService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "matchingId",
				REQUIRED_SERVICE__MATCHING_ID__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateService(Service service, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(service, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateComponent(Component component, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(component, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProvidedService(ProvidedService providedService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		if (!validate_NoCircularContainment(providedService, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateProvidedService_launcherCheckProvided(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateProvidedService_cardCheckRequired(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateProvidedService_matchingId(providedService, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the launcherCheckProvided constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PROVIDED_SERVICE__LAUNCHER_CHECK_PROVIDED__EEXPRESSION = "self.ServiceDescription.Launcher = LauncherTypeProvided";

	/**
	 * Validates the launcherCheckProvided constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProvidedService_launcherCheckProvided(ProvidedService providedService,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate(NewPackage1Package.Literals.PROVIDED_SERVICE, providedService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "launcherCheckProvided",
				PROVIDED_SERVICE__LAUNCHER_CHECK_PROVIDED__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the cardCheckRequired constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PROVIDED_SERVICE__CARD_CHECK_REQUIRED__EEXPRESSION = "self.bindRequired -> size() < self.ServiceDescription.Cardinality ";

	/**
	 * Validates the cardCheckRequired constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProvidedService_cardCheckRequired(ProvidedService providedService,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate(NewPackage1Package.Literals.PROVIDED_SERVICE, providedService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "cardCheckRequired",
				PROVIDED_SERVICE__CARD_CHECK_REQUIRED__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the matchingId constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PROVIDED_SERVICE__MATCHING_ID__EEXPRESSION = "self.bindRequired -> forAll(s | s.ServiceDescription.MatchingID = self.ServiceDescription.MatchingID)";

	/**
	 * Validates the matchingId constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProvidedService_matchingId(ProvidedService providedService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(NewPackage1Package.Literals.PROVIDED_SERVICE, providedService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "matchingId",
				PROVIDED_SERVICE__MATCHING_ID__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //NewPackage1Validator
