/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Factory
 * @model kind="package"
 * @generated
 */
public interface NewPackage2Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Component_Service_Description";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/sirius/sample/iCE_beta_desc";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "desc_ice";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NewPackage2Package eINSTANCE = org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.NewPackage2PackageImpl
			.init();

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ComponentDescriptionImpl <em>Component Description</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ComponentDescriptionImpl
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.NewPackage2PackageImpl#getComponentDescription()
	 * @generated
	 */
	int COMPONENT_DESCRIPTION = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_DESCRIPTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_DESCRIPTION__ROLE = 1;

	/**
	 * The feature id for the '<em><b>State</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_DESCRIPTION__STATE = 2;

	/**
	 * The number of structural features of the '<em>Component Description</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_DESCRIPTION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Component Description</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPONENT_DESCRIPTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ServiceDescriptionImpl <em>Service Description</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ServiceDescriptionImpl
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.NewPackage2PackageImpl#getServiceDescription()
	 * @generated
	 */
	int SERVICE_DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_DESCRIPTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Launcher</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_DESCRIPTION__LAUNCHER = 1;

	/**
	 * The feature id for the '<em><b>IO Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_DESCRIPTION__IO_ACTION = 2;

	/**
	 * The feature id for the '<em><b>Textual Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_DESCRIPTION__TEXTUAL_DESCRIPTION = 3;

	/**
	 * The feature id for the '<em><b>Rule</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_DESCRIPTION__RULE = 4;

	/**
	 * The number of structural features of the '<em>Service Description</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_DESCRIPTION_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Service Description</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_DESCRIPTION_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription <em>Component Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Component Description</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription
	 * @generated
	 */
	EClass getComponentDescription();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription#getName()
	 * @see #getComponentDescription()
	 * @generated
	 */
	EAttribute getComponentDescription_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription#getRole <em>Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Role</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription#getRole()
	 * @see #getComponentDescription()
	 * @generated
	 */
	EAttribute getComponentDescription_Role();

	/**
	 * Returns the meta object for the attribute list '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>State</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription#getState()
	 * @see #getComponentDescription()
	 * @generated
	 */
	EAttribute getComponentDescription_State();

	/**
	 * Returns the meta object for class '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription <em>Service Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service Description</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription
	 * @generated
	 */
	EClass getServiceDescription();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getName()
	 * @see #getServiceDescription()
	 * @generated
	 */
	EAttribute getServiceDescription_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getLauncher <em>Launcher</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Launcher</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getLauncher()
	 * @see #getServiceDescription()
	 * @generated
	 */
	EAttribute getServiceDescription_Launcher();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getIOAction <em>IO Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>IO Action</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getIOAction()
	 * @see #getServiceDescription()
	 * @generated
	 */
	EAttribute getServiceDescription_IOAction();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getTextualDescription <em>Textual Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Textual Description</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getTextualDescription()
	 * @see #getServiceDescription()
	 * @generated
	 */
	EAttribute getServiceDescription_TextualDescription();

	/**
	 * Returns the meta object for the containment reference '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getRule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Rule</em>'.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription#getRule()
	 * @see #getServiceDescription()
	 * @generated
	 */
	EReference getServiceDescription_Rule();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	NewPackage2Factory getNewPackage2Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ComponentDescriptionImpl <em>Component Description</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ComponentDescriptionImpl
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.NewPackage2PackageImpl#getComponentDescription()
		 * @generated
		 */
		EClass COMPONENT_DESCRIPTION = eINSTANCE.getComponentDescription();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPONENT_DESCRIPTION__NAME = eINSTANCE.getComponentDescription_Name();

		/**
		 * The meta object literal for the '<em><b>Role</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPONENT_DESCRIPTION__ROLE = eINSTANCE.getComponentDescription_Role();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPONENT_DESCRIPTION__STATE = eINSTANCE.getComponentDescription_State();

		/**
		 * The meta object literal for the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ServiceDescriptionImpl <em>Service Description</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.ServiceDescriptionImpl
		 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl.NewPackage2PackageImpl#getServiceDescription()
		 * @generated
		 */
		EClass SERVICE_DESCRIPTION = eINSTANCE.getServiceDescription();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_DESCRIPTION__NAME = eINSTANCE.getServiceDescription_Name();

		/**
		 * The meta object literal for the '<em><b>Launcher</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_DESCRIPTION__LAUNCHER = eINSTANCE.getServiceDescription_Launcher();

		/**
		 * The meta object literal for the '<em><b>IO Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_DESCRIPTION__IO_ACTION = eINSTANCE.getServiceDescription_IOAction();

		/**
		 * The meta object literal for the '<em><b>Textual Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_DESCRIPTION__TEXTUAL_DESCRIPTION = eINSTANCE.getServiceDescription_TextualDescription();

		/**
		 * The meta object literal for the '<em><b>Rule</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVICE_DESCRIPTION__RULE = eINSTANCE.getServiceDescription_Rule();

	}

} //NewPackage2Package
