/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.NewPackage1Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Structural_Application.RequiredService;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Required Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RequiredServiceImpl extends ServiceImpl implements RequiredService {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequiredServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewPackage1Package.Literals.REQUIRED_SERVICE;
	}

} //RequiredServiceImpl
