/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.Service#getServiceDescription <em>Service Description</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.Service#getProfile <em>Profile</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.Service#getBoundTo <em>Bound To</em>}</li>
 * </ul>
 *
 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package#getService()
 * @model abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='matchingId'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot matchingId='self.boundTo -&gt; forAll(s | s.Profile = self.Profile)'"
 * @generated
 */
public interface Service extends EObject {
	/**
	 * Returns the value of the '<em><b>Service Description</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service Description</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service Description</em>' containment reference.
	 * @see #setServiceDescription(ServiceDescription)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package#getService_ServiceDescription()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ServiceDescription getServiceDescription();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.Service#getServiceDescription <em>Service Description</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service Description</em>' containment reference.
	 * @see #getServiceDescription()
	 * @generated
	 */
	void setServiceDescription(ServiceDescription value);

	/**
	 * Returns the value of the '<em><b>Profile</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Profile</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Profile</em>' attribute.
	 * @see #setProfile(String)
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package#getService_Profile()
	 * @model required="true"
	 * @generated
	 */
	String getProfile();

	/**
	 * Sets the value of the '{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.Service#getProfile <em>Profile</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Profile</em>' attribute.
	 * @see #getProfile()
	 * @generated
	 */
	void setProfile(String value);

	/**
	 * Returns the value of the '<em><b>Bound To</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.Service}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bound To</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bound To</em>' reference list.
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package#getService_BoundTo()
	 * @model
	 * @generated
	 */
	EList<Service> getBoundTo();

} // Service
