/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.Service;

import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.impl.ServiceImpl#getServiceDescription <em>Service Description</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.impl.ServiceImpl#getProfile <em>Profile</em>}</li>
 *   <li>{@link org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.impl.ServiceImpl#getBoundTo <em>Bound To</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ServiceImpl extends MinimalEObjectImpl.Container implements Service {
	/**
	 * The cached value of the '{@link #getServiceDescription() <em>Service Description</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServiceDescription()
	 * @generated
	 * @ordered
	 */
	protected ServiceDescription serviceDescription;

	/**
	 * The default value of the '{@link #getProfile() <em>Profile</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProfile()
	 * @generated
	 * @ordered
	 */
	protected static final String PROFILE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProfile() <em>Profile</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProfile()
	 * @generated
	 * @ordered
	 */
	protected String profile = PROFILE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBoundTo() <em>Bound To</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBoundTo()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> boundTo;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewPackage1Package.Literals.SERVICE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServiceDescription getServiceDescription() {
		return serviceDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetServiceDescription(ServiceDescription newServiceDescription,
			NotificationChain msgs) {
		ServiceDescription oldServiceDescription = serviceDescription;
		serviceDescription = newServiceDescription;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					NewPackage1Package.SERVICE__SERVICE_DESCRIPTION, oldServiceDescription, newServiceDescription);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setServiceDescription(ServiceDescription newServiceDescription) {
		if (newServiceDescription != serviceDescription) {
			NotificationChain msgs = null;
			if (serviceDescription != null)
				msgs = ((InternalEObject) serviceDescription).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - NewPackage1Package.SERVICE__SERVICE_DESCRIPTION, null, msgs);
			if (newServiceDescription != null)
				msgs = ((InternalEObject) newServiceDescription).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - NewPackage1Package.SERVICE__SERVICE_DESCRIPTION, null, msgs);
			msgs = basicSetServiceDescription(newServiceDescription, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NewPackage1Package.SERVICE__SERVICE_DESCRIPTION,
					newServiceDescription, newServiceDescription));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProfile() {
		return profile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProfile(String newProfile) {
		String oldProfile = profile;
		profile = newProfile;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NewPackage1Package.SERVICE__PROFILE, oldProfile,
					profile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getBoundTo() {
		if (boundTo == null) {
			boundTo = new EObjectResolvingEList<Service>(Service.class, this, NewPackage1Package.SERVICE__BOUND_TO);
		}
		return boundTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			return basicSetServiceDescription(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			return getServiceDescription();
		case NewPackage1Package.SERVICE__PROFILE:
			return getProfile();
		case NewPackage1Package.SERVICE__BOUND_TO:
			return getBoundTo();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			setServiceDescription((ServiceDescription) newValue);
			return;
		case NewPackage1Package.SERVICE__PROFILE:
			setProfile((String) newValue);
			return;
		case NewPackage1Package.SERVICE__BOUND_TO:
			getBoundTo().clear();
			getBoundTo().addAll((Collection<? extends Service>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			setServiceDescription((ServiceDescription) null);
			return;
		case NewPackage1Package.SERVICE__PROFILE:
			setProfile(PROFILE_EDEFAULT);
			return;
		case NewPackage1Package.SERVICE__BOUND_TO:
			getBoundTo().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewPackage1Package.SERVICE__SERVICE_DESCRIPTION:
			return serviceDescription != null;
		case NewPackage1Package.SERVICE__PROFILE:
			return PROFILE_EDEFAULT == null ? profile != null : !PROFILE_EDEFAULT.equals(profile);
		case NewPackage1Package.SERVICE__BOUND_TO:
			return boundTo != null && !boundTo.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Profile: ");
		result.append(profile);
		result.append(')');
		return result.toString();
	}

} //ServiceImpl
