/**
 */
package org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.NewPackage1Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Assembly.impl.NewPackage1PackageImpl;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.NewPackage3Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Behavioral_Component_Service_Application_Rule.impl.NewPackage3PackageImpl;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ComponentDescription;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Factory;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package;
import org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.ServiceDescription;

import org.eclipse.sirius.icebeta.sample.iCE_beta.ICE_betaPackage;
import org.eclipse.sirius.icebeta.sample.iCE_beta.impl.ICE_betaPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NewPackage2PackageImpl extends EPackageImpl implements NewPackage2Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass componentDescriptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serviceDescriptionEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.sirius.icebeta.sample.iCE_beta.Component_Service_Description.NewPackage2Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private NewPackage2PackageImpl() {
		super(eNS_URI, NewPackage2Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link NewPackage2Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static NewPackage2Package init() {
		if (isInited)
			return (NewPackage2Package) EPackage.Registry.INSTANCE.getEPackage(NewPackage2Package.eNS_URI);

		// Obtain or create and register package
		Object registeredNewPackage2Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		NewPackage2PackageImpl theNewPackage2Package = registeredNewPackage2Package instanceof NewPackage2PackageImpl
				? (NewPackage2PackageImpl) registeredNewPackage2Package
				: new NewPackage2PackageImpl();

		isInited = true;

		// Initialize simple dependencies
		NewPackage1Package.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		Object registeredPackage = EPackage.Registry.INSTANCE.getEPackage(ICE_betaPackage.eNS_URI);
		ICE_betaPackageImpl theICE_betaPackage = (ICE_betaPackageImpl) (registeredPackage instanceof ICE_betaPackageImpl
				? registeredPackage
				: ICE_betaPackage.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(NewPackage1Package.eNS_URI);
		NewPackage1PackageImpl theNewPackage1Package = (NewPackage1PackageImpl) (registeredPackage instanceof NewPackage1PackageImpl
				? registeredPackage
				: NewPackage1Package.eINSTANCE);
		registeredPackage = EPackage.Registry.INSTANCE.getEPackage(NewPackage3Package.eNS_URI);
		NewPackage3PackageImpl theNewPackage3Package = (NewPackage3PackageImpl) (registeredPackage instanceof NewPackage3PackageImpl
				? registeredPackage
				: NewPackage3Package.eINSTANCE);

		// Create package meta-data objects
		theNewPackage2Package.createPackageContents();
		theICE_betaPackage.createPackageContents();
		theNewPackage1Package.createPackageContents();
		theNewPackage3Package.createPackageContents();

		// Initialize created meta-data
		theNewPackage2Package.initializePackageContents();
		theICE_betaPackage.initializePackageContents();
		theNewPackage1Package.initializePackageContents();
		theNewPackage3Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theNewPackage2Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(NewPackage2Package.eNS_URI, theNewPackage2Package);
		return theNewPackage2Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getComponentDescription() {
		return componentDescriptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComponentDescription_Name() {
		return (EAttribute) componentDescriptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComponentDescription_Role() {
		return (EAttribute) componentDescriptionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComponentDescription_State() {
		return (EAttribute) componentDescriptionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getServiceDescription() {
		return serviceDescriptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceDescription_Name() {
		return (EAttribute) serviceDescriptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceDescription_Launcher() {
		return (EAttribute) serviceDescriptionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceDescription_IOAction() {
		return (EAttribute) serviceDescriptionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceDescription_TextualDescription() {
		return (EAttribute) serviceDescriptionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getServiceDescription_Rule() {
		return (EReference) serviceDescriptionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewPackage2Factory getNewPackage2Factory() {
		return (NewPackage2Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		componentDescriptionEClass = createEClass(COMPONENT_DESCRIPTION);
		createEAttribute(componentDescriptionEClass, COMPONENT_DESCRIPTION__NAME);
		createEAttribute(componentDescriptionEClass, COMPONENT_DESCRIPTION__ROLE);
		createEAttribute(componentDescriptionEClass, COMPONENT_DESCRIPTION__STATE);

		serviceDescriptionEClass = createEClass(SERVICE_DESCRIPTION);
		createEAttribute(serviceDescriptionEClass, SERVICE_DESCRIPTION__NAME);
		createEAttribute(serviceDescriptionEClass, SERVICE_DESCRIPTION__LAUNCHER);
		createEAttribute(serviceDescriptionEClass, SERVICE_DESCRIPTION__IO_ACTION);
		createEAttribute(serviceDescriptionEClass, SERVICE_DESCRIPTION__TEXTUAL_DESCRIPTION);
		createEReference(serviceDescriptionEClass, SERVICE_DESCRIPTION__RULE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		NewPackage3Package theNewPackage3Package = (NewPackage3Package) EPackage.Registry.INSTANCE
				.getEPackage(NewPackage3Package.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(componentDescriptionEClass, ComponentDescription.class, "ComponentDescription", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getComponentDescription_Name(), ecorePackage.getEString(), "Name", null, 1, 1,
				ComponentDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getComponentDescription_Role(), ecorePackage.getEString(), "Role", null, 1, 1,
				ComponentDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getComponentDescription_State(), ecorePackage.getEString(), "State", null, 0, -1,
				ComponentDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(serviceDescriptionEClass, ServiceDescription.class, "ServiceDescription", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getServiceDescription_Name(), ecorePackage.getEString(), "Name", null, 1, 1,
				ServiceDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getServiceDescription_Launcher(), ecorePackage.getEString(), "Launcher", null, 1, 1,
				ServiceDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getServiceDescription_IOAction(), ecorePackage.getEString(), "IOAction", null, 1, 1,
				ServiceDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getServiceDescription_TextualDescription(), ecorePackage.getEString(), "TextualDescription",
				null, 1, 1, ServiceDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getServiceDescription_Rule(), theNewPackage3Package.getCombinationRule(), null, "rule", null, 1,
				1, ServiceDescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
	}

} //NewPackage2PackageImpl
