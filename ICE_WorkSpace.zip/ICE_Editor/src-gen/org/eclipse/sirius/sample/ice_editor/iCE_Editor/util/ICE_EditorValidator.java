/**
 */
package org.eclipse.sirius.sample.ice_editor.iCE_Editor.util;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import org.eclipse.sirius.sample.ice_editor.iCE_Editor.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.sirius.sample.ice_editor.iCE_Editor.ICE_EditorPackage
 * @generated
 */
public class ICE_EditorValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final ICE_EditorValidator INSTANCE = new ICE_EditorValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "org.eclipse.sirius.sample.ice_editor.iCE_Editor";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ICE_EditorValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
		return ICE_EditorPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		switch (classifierID) {
		case ICE_EditorPackage.COMPONENT:
			return validateComponent((Component) value, diagnostics, context);
		case ICE_EditorPackage.SERVICE:
			return validateService((Service) value, diagnostics, context);
		case ICE_EditorPackage.REQUIRED_SERVICE:
			return validateRequiredService((RequiredService) value, diagnostics, context);
		case ICE_EditorPackage.PROVIDED_SERVICE:
			return validateProvidedService((ProvidedService) value, diagnostics, context);
		case ICE_EditorPackage.ENVIRONMENT:
			return validateEnvironment((Environment) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateComponent(Component component, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(component, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateComponent_nameCondition(component, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateComponent_serviceCondition(component, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the nameCondition constraint of '<em>Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COMPONENT__NAME_CONDITION__EEXPRESSION = "Component.allInstances()->forAll(c1, c2 | c1 <> c2 implies c1.Name <> c2.Name)";

	/**
	 * Validates the nameCondition constraint of '<em>Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateComponent_nameCondition(Component component, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(ICE_EditorPackage.Literals.COMPONENT, component, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "nameCondition",
				COMPONENT__NAME_CONDITION__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the serviceCondition constraint of '<em>Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COMPONENT__SERVICE_CONDITION__EEXPRESSION = "self.service -> forAll(s1, s2 | s1 <> s2 implies s1.Name <> s2.Name)";

	/**
	 * Validates the serviceCondition constraint of '<em>Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateComponent_serviceCondition(Component component, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(ICE_EditorPackage.Literals.COMPONENT, component, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "serviceCondition",
				COMPONENT__SERVICE_CONDITION__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateService(Service service, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(service, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(service, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateService_rulecheck(service, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the rulecheck constraint of '<em>Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SERVICE__RULECHECK__EEXPRESSION = "self.Rules -> \n"
			+ "\t\t\tforAll(r | r.matches('^Launcher\\\\s(AND\\\\sSTATE(==|<|>|<=|>=)(\\\\w)+\\\\s|AND\\\\sVAL@INPUT((==|<|>|<=|>=)(\\\\w)+)*\\\\s)*-->\\\\s(IOAction|STATE=(\\\\w)+|IOAction\\\\sAND\\\\sSTATE=(\\\\w)+|NOP)$'))\n"
			+ "";

	/**
	 * Validates the rulecheck constraint of '<em>Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateService_rulecheck(Service service, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(ICE_EditorPackage.Literals.SERVICE, service, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "rulecheck", SERVICE__RULECHECK__EEXPRESSION,
				Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequiredService(RequiredService requiredService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		if (!validate_NoCircularContainment(requiredService, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateService_rulecheck(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateRequiredService_cardCheckProv(requiredService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateRequiredService_bindProvCheck(requiredService, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the cardCheckProv constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String REQUIRED_SERVICE__CARD_CHECK_PROV__EEXPRESSION = "self.bindProvided -> size()<=Cardinality";

	/**
	 * Validates the cardCheckProv constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequiredService_cardCheckProv(RequiredService requiredService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(ICE_EditorPackage.Literals.REQUIRED_SERVICE, requiredService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "cardCheckProv",
				REQUIRED_SERVICE__CARD_CHECK_PROV__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the bindProvCheck constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String REQUIRED_SERVICE__BIND_PROV_CHECK__EEXPRESSION = "self.bindProvided -> forAll(s | s.ID = self.ID)";

	/**
	 * Validates the bindProvCheck constraint of '<em>Required Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRequiredService_bindProvCheck(RequiredService requiredService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(ICE_EditorPackage.Literals.REQUIRED_SERVICE, requiredService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "bindProvCheck",
				REQUIRED_SERVICE__BIND_PROV_CHECK__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProvidedService(ProvidedService providedService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		if (!validate_NoCircularContainment(providedService, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateService_rulecheck(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateProvidedService_cardCheckReq(providedService, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateProvidedService_bindReqCheck(providedService, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the cardCheckReq constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PROVIDED_SERVICE__CARD_CHECK_REQ__EEXPRESSION = "self.bindRequired -> size()<=Cardinality";

	/**
	 * Validates the cardCheckReq constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProvidedService_cardCheckReq(ProvidedService providedService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(ICE_EditorPackage.Literals.PROVIDED_SERVICE, providedService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "cardCheckReq",
				PROVIDED_SERVICE__CARD_CHECK_REQ__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * The cached validation expression for the bindReqCheck constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PROVIDED_SERVICE__BIND_REQ_CHECK__EEXPRESSION = "self.bindRequired -> forAll(s | s.ID = self.ID)";

	/**
	 * Validates the bindReqCheck constraint of '<em>Provided Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProvidedService_bindReqCheck(ProvidedService providedService, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(ICE_EditorPackage.Literals.PROVIDED_SERVICE, providedService, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "bindReqCheck",
				PROVIDED_SERVICE__BIND_REQ_CHECK__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEnvironment(Environment environment, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(environment, diagnostics, context);
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //ICE_EditorValidator
